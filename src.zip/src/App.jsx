import {
  Box,
} from "@mui/material";
 
import {
  BrowserRouter,
  Navigate,
  Route,
  Routes,
} from "react-router-dom";
 
import GicsMaster
  from "./pages/GicsMaster";

import Sidebar
  from "./components/Sidebar";
 
import ThemeAllocation
  from "./pages/ThemeAllocation";

import SecurityMaster
  from "./pages/SecurityMaster";
 
import AssetClasses
  from "./pages/AssetClasses";

import InvestmentThemes
  from "./pages/InvestmentThemes";

import Benchmarks from "./pages/Benchmarks";
import MarketPrices from "./pages/MarketPrices";

const drawerWidth = 240;
 
 
function EmptyPage({
  title
}) {
 
  return (
 
    <Box>
 
      <h2>
        {title}
      </h2>
 
      <p>
        This Data Grid will be
        implemented next.
      </p>
 
    </Box>
 
  );
}
 
 
function App() {
 
  return (
 
    <BrowserRouter>
 
      <Sidebar />
 
 
      <Box
        component="main"
 
        sx={{
          marginLeft:
            `${drawerWidth}px`,
 
          padding: 3,
 
          minHeight: "100vh",
 
          backgroundColor:
            "#f5f6f8",
        }}
      >
 
        <Routes>
 
          <Route
            path="/"
            element={
              <Navigate
                to="/securities"
              />
            }
          />
 
 
          <Route
            path="/securities"
            element={
              <SecurityMaster />
            }
          />
 
 
          <Route
            path="/asset-classes"
            element={
              <AssetClasses />
            }
          />
 
 
          <Route
            path="/gics"
            element={
              <GicsMaster />
            }
          />
 
 
          <Route
            path="/themes"
            element={
              <InvestmentThemes />
            }
          />
 
 
          <Route
            path="/theme-allocation"
            element={
              <ThemeAllocation />
            }
          />
 
 
          <Route
            path="/market-prices"
            element={
              <MarketPrices />
            }
          />
 
 
          <Route
            path="/benchmarks"
            element={
              <Benchmarks />
            }
          />
 
        </Routes>
 
      </Box>
 
    </BrowserRouter>
  );
}
 
 
export default App;