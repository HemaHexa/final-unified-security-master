import {
  useEffect,
  useState,
} from "react";
 
import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
  MenuItem,
  TextField,
  Tooltip,
  Typography,
} from "@mui/material";
 
import {
  DataGrid,
} from "@mui/x-data-grid";
 
import AddIcon
  from "@mui/icons-material/Add";
 
import EditIcon
  from "@mui/icons-material/Edit";
 
import {
  createTheme,
  getThemes,
  updateTheme,
} from "../api/api";
 
 
const emptyForm = {
 
  theme_name: "",
 
  description: "",
 
  risk_level: "",
 
  investment_horizon: "",
 
  status: "ACTIVE",
};
 
 
function InvestmentThemes() {
 
  const [rows, setRows] =
    useState([]);
 
  const [loading, setLoading] =
    useState(false);
 
  const [dialogOpen, setDialogOpen] =
    useState(false);
 
  const [editingId, setEditingId] =
    useState(null);
 
  const [form, setForm] =
    useState(emptyForm);
 
  const [message, setMessage] =
    useState("");
 
 
  // ====================================================
  // LOAD THEMES
  // ====================================================
 
  async function loadThemes() {
 
    try {
 
      setLoading(true);
 
      const data =
        await getThemes();
 
      setRows(data);
 
    }
    catch (error) {
 
      console.error(
        "Theme loading error:",
        error
      );
 
    }
    finally {
 
      setLoading(false);
    }
  }
 
 
  useEffect(() => {
 
    loadThemes();
 
  }, []);
 
 
  // ====================================================
  // FORM CHANGE
  // ====================================================
 
  function handleChange(event) {
 
    const {
      name,
      value
    } = event.target;
 
 
    setForm(
      previous => ({
        ...previous,
        [name]: value,
      })
    );
  }
 
 
  // ====================================================
  // ADD
  // ====================================================
 
  function handleAdd() {
 
    setEditingId(null);
 
    setForm(emptyForm);
 
    setMessage("");
 
    setDialogOpen(true);
  }
 
 
  // ====================================================
  // EDIT
  // ====================================================
 
  function handleEdit(row) {
 
    setEditingId(
      row.theme_id
    );
 
 
    setForm({
 
      theme_name:
        row.theme_name || "",
 
      description:
        row.description || "",
 
      risk_level:
        row.risk_level || "",
 
      investment_horizon:
        row.investment_horizon || "",
 
      status:
        row.status || "ACTIVE",
    });
 
 
    setMessage("");
 
    setDialogOpen(true);
  }
 
 
  // ====================================================
  // SAVE
  // ====================================================
 
  async function handleSave() {
 
    if (
      form.theme_name.trim() === ""
    ) {
 
      setMessage(
        "Theme Name is required"
      );
 
      return;
    }
 
 
    try {
 
      if (editingId) {
 
        await updateTheme(
          editingId,
          form
        );
 
      }
      else {
 
        await createTheme(
          form
        );
      }
 
 
      setDialogOpen(false);
 
      setEditingId(null);
 
      setForm(emptyForm);
 
      await loadThemes();
 
    }
    catch (error) {
 
      console.error(
        "Theme save error:",
        error
      );
 
      setMessage(
        "Unable to save theme"
      );
    }
  }
 
 
  // ====================================================
  // GRID COLUMNS
  // ====================================================
 
  const columns = [
 
    {
      field: "theme_id",
      headerName: "ID",
      width: 80,
    },
 
    {
      field: "theme_name",
      headerName: "Theme Name",
      width: 180,
    },
 
    {
      field: "description",
      headerName: "Description",
      width: 300,
    },
 
    {
      field: "risk_level",
      headerName: "Risk Level",
      width: 140,
    },
 
    {
      field: "investment_horizon",
      headerName:
        "Investment Horizon",
      width: 200,
    },
 
    {
      field: "status",
      headerName: "Status",
      width: 120,
    },
 
    {
      field: "actions",
      headerName: "Action",
      width: 100,
 
      sortable: false,
 
      filterable: false,
 
      renderCell: (params) => (
 
        <Tooltip title="Edit">
 
          <IconButton
            onClick={() =>
              handleEdit(
                params.row
              )
            }
          >
 
            <EditIcon />
 
          </IconButton>
 
        </Tooltip>
      ),
    },
  ];
 
 
  return (
 
    <Box>
 
      {/* HEADER */}
 
      <Box
        sx={{
          display: "flex",
          justifyContent:
            "space-between",
          alignItems: "center",
          mb: 3,
        }}
      >
 
        <Box>
 
          <Typography
            variant="h4"
            fontWeight="bold"
          >
            Investment Themes
          </Typography>
 
          <Typography
            color="text.secondary"
          >
            Manage portfolio
            investment strategies
          </Typography>
 
        </Box>
 
 
        <Button
          variant="contained"
 
          startIcon={
            <AddIcon />
          }
 
          onClick={handleAdd}
        >
          Add Theme
        </Button>
 
      </Box>
 
 
      {/* DATA GRID */}
 
      <Box
        sx={{
          height: 600,
          width: "100%",
        }}
      >
 
        <DataGrid
 
          rows={rows}
 
          columns={columns}
 
          getRowId={
            (row) =>
              row.theme_id
          }
 
          loading={loading}
 
          pageSizeOptions={[
            5,
            10,
            25,
          ]}
 
          initialState={{
            pagination: {
              paginationModel: {
                page: 0,
                pageSize: 10,
              },
            },
          }}
 
          disableRowSelectionOnClick
 
          showToolbar
 
        />
 
      </Box>
 
 
      {/* ADD / EDIT DIALOG */}
 
      <Dialog
 
        open={dialogOpen}
 
        onClose={() =>
          setDialogOpen(false)
        }
 
        fullWidth
 
        maxWidth="md"
      >
 
        <DialogTitle>
 
          {
            editingId
              ? "Edit Investment Theme"
              : "Add Investment Theme"
          }
 
        </DialogTitle>
 
 
        <DialogContent>
 
          <Box
            sx={{
              display: "grid",
 
              gridTemplateColumns:
                "1fr 1fr",
 
              gap: 2,
 
              mt: 1,
            }}
          >
 
            <TextField
              label="Theme Name"
 
              name="theme_name"
 
              value={
                form.theme_name
              }
 
              onChange={
                handleChange
              }
 
              required
            />
 
 
            <TextField
              select
 
              label="Risk Level"
 
              name="risk_level"
 
              value={
                form.risk_level
              }
 
              onChange={
                handleChange
              }
            >
 
              <MenuItem value="">
                Select Risk
              </MenuItem>
 
              <MenuItem value="Low">
                Low
              </MenuItem>
 
              <MenuItem value="Medium">
                Medium
              </MenuItem>
 
              <MenuItem value="High">
                High
              </MenuItem>
 
            </TextField>
 
 
            <TextField
              label="Investment Horizon"
 
              name="investment_horizon"
 
              value={
                form.investment_horizon
              }
 
              onChange={
                handleChange
              }
            />
 
 
            <TextField
              select
 
              label="Status"
 
              name="status"
 
              value={
                form.status
              }
 
              onChange={
                handleChange
              }
            >
 
              <MenuItem value="ACTIVE">
                ACTIVE
              </MenuItem>
 
              <MenuItem value="INACTIVE">
                INACTIVE
              </MenuItem>
 
            </TextField>
 
 
            <TextField
              label="Description"
 
              name="description"
 
              value={
                form.description
              }
 
              onChange={
                handleChange
              }
 
              multiline
 
              rows={4}
 
              sx={{
                gridColumn:
                  "1 / 3",
              }}
            />
 
          </Box>
 
 
          {
            message &&
            (
              <Typography
                color="error"
 
                sx={{
                  mt: 2,
                }}
              >
                {message}
              </Typography>
            )
          }
 
        </DialogContent>
 
 
        <DialogActions>
 
          <Button
            onClick={() =>
              setDialogOpen(false)
            }
          >
            Cancel
          </Button>
 
 
          <Button
            variant="contained"
 
            onClick={
              handleSave
            }
          >
 
            {
              editingId
                ? "Update"
                : "Save"
            }
 
          </Button>
 
        </DialogActions>
 
      </Dialog>
 
    </Box>
  );
}
 
 
export default InvestmentThemes;