import {
  useEffect,
  useState,
} from "react";
 
import {
  Box,
  Typography,
} from "@mui/material";
 
import {
  DataGrid,
} from "@mui/x-data-grid";
 
import {
  getGics,
} from "../api/api";
 
 
function GicsMaster() {
 
  const [rows, setRows] =
    useState([]);
 
  const [loading, setLoading] =
    useState(false);
 
 
  async function loadGics() {
 
    try {
 
      setLoading(true);
 
      const data =
        await getGics();
 
      setRows(data);
 
    }
    catch (error) {
 
      console.error(
        "GICS loading error:",
        error
      );
 
    }
    finally {
 
      setLoading(false);
    }
  }
 
 
  useEffect(() => {
 
    loadGics();
 
  }, []);
 
 
  const columns = [
 
    {
      field: "gics_id",
      headerName: "ID",
      width: 80,
    },
 
    {
      field: "sector_code",
      headerName: "Sector Code",
      width: 140,
    },
 
    {
      field: "sector_name",
      headerName: "Sector Name",
      width: 220,
    },
 
    {
      field: "industry",
      headerName: "Industry",
      width: 240,
    },
 
    {
      field: "industry_name",
      headerName: "Industry Name",
      width: 240,
    },
 
    {
      field: "description",
      headerName: "Description",
      width: 300,
    },
  ];
 
 
  return (
 
    <Box>
 
      <Typography
        variant="h4"
        fontWeight="bold"
        sx={{
          mb: 1,
        }}
      >
        GICS
      </Typography>
 
 
      <Typography
        color="text.secondary"
        sx={{
          mb: 3,
        }}
      >
        Global Industry Classification
        Standard
      </Typography>
 
 
      <Box
        sx={{
          height: 620,
          width: "100%",
        }}
      >
 
        <DataGrid
 
          rows={rows}
 
          columns={columns}
 
          getRowId={
            (row) =>
              row.gics_id
          }
 
          loading={loading}
 
          pageSizeOptions={[
            5,
            10,
            25,
          ]}
 
          initialState={{
            pagination: {
              paginationModel: {
                page: 0,
                pageSize: 10,
              },
            },
          }}
 
          disableRowSelectionOnClick
 
          showToolbar
 
        />
 
      </Box>
 
    </Box>
  );
}
 
 
export default GicsMaster;